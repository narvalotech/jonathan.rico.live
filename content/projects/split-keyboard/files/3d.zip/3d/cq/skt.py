#!/usr/bin/env python3

import cadquery as cq


def inc(val, inc, center):
    if val > center:
        val += inc
    else:
        val -= inc
    return val


def scale(point, factor):
    x, y = point
    x = inc(x, factor, 50)
    y = inc(y, factor, 50)

    return (x, y)


pcb = [(49, 0),
       (132, 0),
       (142, 20),
       (142, 101),
       (0, 101),
       (0, 19)]

pad1_thick2 = 2
pad1_pts = [scale(pt, 2) for pt in pcb]

pcb_thick = 1.6
bot_holes_height = 2
bot_thick = 2
pcb_to_bot = pcb_thick + bot_holes_height + bot_thick

pcb_to_top_shell = 3.6
top_shell_thick = .5
holes_height = pcb_to_top_shell + top_shell_thick - pad1_thick2

pad1_thick = pcb_to_top_shell + top_shell_thick + pcb_to_bot

# Draw the base pad
result = cq.Workplane('front').polyline(pad1_pts).close().extrude(pad1_thick)

# Fillet edges
result = result.edges("|Z and (<X or >X or <Y or >Y)").fillet(3)

# Fillet edges 2 electric boogaloo
result = result.edges("|X and (<X or >X or <Y or >Y)").fillet(2)

# Cut the void for the PCB
pcb_padded = [scale(pt, .5) for pt in pcb] # add .5mm padding around the pcb
result = result.polyline(pcb_padded).close().cutBlind(pad1_thick - pad1_thick2)

# Make stabilizer pads
slot_w = 2
slot_l = 50
slot_spacing = 18
nslots = 6
slot_x = -6.5
slot_y = 20
slot_z = holes_height + .1

p1 = result
plane = result.workplane(origin=(nslots/2 * slot_spacing + slot_x, slot_l/2 + slot_y, 0))
slots = plane.rarray(slot_spacing, 1, nslots, 1).slot2D(slot_l, slot_w, 90).extrude(-slot_z)
result = result.union(slots, glue=True)

# Make another stabilizer pad
plane = p1.workplane(origin=(16, 98, 0))
slots = plane.rarray(1, 1, 1, 1).slot2D(20, 4, 0).extrude(-(holes_height + pcb_thick + bot_holes_height))
result = result.union(slots, glue=True)

# Make hole pads
holes_pos = [(43, -7), (129, -4), (133, -96), (21, -74)]
plane = p1.faces("<Z[-2]").workplane()
obj = plane.pushPoints(holes_pos).circle(3.5).extrude(holes_height)
result = result.union(obj, glue=True)

# Make holes
plane = result.faces("<Z[-5]").workplane()  # same base as hole pads
result = plane.pushPoints(holes_pos).circle(1).cutBlind(10)

# Cut the MCU header slots
s1 = cq.Workplane('front').box(7, 44, 40, centered=(0, 0, 0)).translate([115.5, 51, 0])
s2 = cq.Workplane('front').box(7, 44, 40, centered=(0, 0, 0)).translate([135.5, 51, 0])
result = result.cut(s1).cut(s2)

# Cut the keyholes
print_tol = .5
key_x = 15 + print_tol
key_x_inner = 13.8 + .2

num_keys = 4
height = 6
row_x = 18
spacing_x = 18
STAGGER = [0, 1, 4, 4 + 2, 4, 2]


def make_key(wp, inner, outer, shell, x, y, z):
    outer_depth = 20
    key = wp.box(inner, inner, 40)  # Go through all the material
    key = key.union(wp.box(outer, outer, outer_depth))
    key = key.translate([x, y, -outer_depth/2 - shell + z])

    return key


def make_keys(offsets, num):
    row = cq.Workplane('front')

    for i, c in enumerate(offsets):
        for r in range(num):
            row.add(make_key(cq.Workplane('front'),
                             key_x_inner, key_x, top_shell_thick,
                             row_x * i,
                             row_x * r + c,
                             pad1_thick))

    return row


# Maybe drawing the boxes on an array of points and extruding them all
# as one 2D feature is less expensive.
keys = make_keys(STAGGER, num_keys).translate([11.5, 28.5, 0])
# show_object(keys)
result = result.cut(keys)

# Cut the triad keys
stagger_triad = [0, 2, 0]

keys = make_keys(stagger_triad, 1).translate([58.5, 7.5, 0])
result = result.cut(keys)

# Cut the thumb key
key = make_key(cq.Workplane('front'),
               key_x_inner, key_x, top_shell_thick,
               0,
               0,
               pad1_thick)

key = key.rotateAboutCenter((0, 0, 1), -30).translate([119.5, 10.5, 0])
result = result.cut(key)

# Cut USB
obj = cq.Workplane('front').box(20, 12, 40, centered=(0, 0, 0)).translate([134, 35, -40+10])
result = result.cut(obj)
# show_object(obj)

# TODO: Make clips

show_object(result)

cq.exporters.export(result, "skt.step")
