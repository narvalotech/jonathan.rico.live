#!/usr/bin/env python3

import cadquery as cq


def inc(val, inc, center):
    if val > center:
        val += inc
    else:
        val -= inc
    return val


def scale(point, factor):
    x, y = point
    x = inc(x, factor, 50)
    y = inc(y, factor, 50)

    return (x, y)


pcb = [(49, 0),
       (132, 0),
       (142, 20),
       (142, 101),
       (0, 101),
       (0, 19)]

pad1_pts = pcb
pad1_thick = 2
holes_height = 2

# Draw the base pad
result = cq.Workplane('front').polyline(pad1_pts).close().extrude(pad1_thick)

# Make hole pads
holes_pos = [(43, 7), (129, 4), (133, 96), (21, 74)]
plane = result.faces(">Z").workplane()
obj = plane.pushPoints(holes_pos).circle(3).extrude(holes_height).edges(">>Z[-3]").fillet(.2)
result = result.union(obj)

# Fillet the hole pads

# Make holes
plane = result.faces(">Z").workplane()  # same base as hole pads
result = plane.pushPoints(holes_pos).circle(1.2).cutBlind(-10)

# Bottom hole cutouts
plane = result.faces("<Z").workplane()
points = [(x, -y) for (x, y) in holes_pos]
result = plane.pushPoints(points).circle(2.5).cutBlind(-1.5)

# Cut USB
obj = cq.Workplane('front').box(20, 12, 40, centered=(0, 0, 0)).translate([134, 35, 0])
result = result.cut(obj)

show_object(result)

cq.exporters.export(result, "skb.step")
