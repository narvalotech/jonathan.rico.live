Hex.pde -- Clone de SuperHexagon avec controle par accelerometre  (RICO Jonathan - 2016)


---------Installation/demarrage----------

- Pour pouvoir jouer, il faut installer l'environnement de developpement Processing:
http://processing.org  (verifier s'il est deja installe sur le PC avant)

- Il faut ensuite, mettre le dossier "hex" dans le dossier "Processing" dans "Mes Documents"

- Ouvrir le code: Ouvrir processing, faire "file" -> "sketchbook" -> "hex"

- Il faut aussi changer le firmware des cartes RX et TX: flasher les codes imu_gm_TX et imu_gm_RX
sur les cartes respectives en faisant bien attention de CHANGER les adresses, comme indique dans le TP 

- Brancher la carte RX, allumer la carte TX, puis lancer le jeu (bouton "play")

- Deplacer la bille pour sortir du labyrinthe en inclinant la carte TX vers la droite ou la gauche

(Attention plus on fait bouger la bille, plus la vitesse augmente)

- Si le jeu se ferme tout seul, verifier le port serie et relancer



----------Niveaux-----------

- Les  niveaux sont définis dans "levelstorage.pde" par un tableau d'octets:
chaque bit dans l'octet represente un "mur" du labyrinthe (1=mur, 0=vide), avec 
la succession d'octets formant le labyrinthe.

- pour ajouter un niveau, il suffit de rajouter une ligne d'octets initialisés entre accolades
(voir les autres niveaux pour le format) dans le tableau 2d "level"
- il faudra aussi ajouter 1 a "numLevels" (nombre de niveaux -1)



----------Code-----------

- Le jeu a ete programme en 2 jours a l'arrache sans trop connaitre le langage,
il est assez mal optimise, n'a pas de commentaires etc... 
Bref, sentez-vous libres de l'ameliorer/optimiser ou commenter le code