#include <zephyr/drivers/led.h>
#include <zephyr/devicetree.h>
#include <zephyr/logging/log.h>
#include <zephyr/usb/usb_device.h>
#include <zephyr/drivers/uart.h>
#include <zephyr/sys/ring_buffer.h>
#include <zephyr/drivers/pwm.h>
#include <zephyr/sys/__assert.h>
#include <string.h>
#include <stdio.h>

#include "alphabet.h"
#include "serial.h"

LOG_MODULE_REGISTER(main, 3);

BUILD_ASSERT(DT_NODE_HAS_COMPAT(DT_CHOSEN(zephyr_console), zephyr_cdc_acm_uart),
	     "Console device is not ACM CDC UART device");

#define SEG_LED_NODE DT_INST(0, holtek_ht16k33)
#define BAR_LED_NODE DT_INST(1, holtek_ht16k33)

struct __attribute__((packed)) inputs {
    uint16_t pot[3];
    uint16_t slider[3];
    uint16_t selector;
    uint16_t keypad;
    uint8_t  buttons;
    uint8_t  toggles;
} inputs;

K_SEM_DEFINE(serial_data, 0, 1);
RING_BUF_DECLARE(uart_ringbuf, 512);
static struct rx_uart_header uart_header;
static struct rx_uart config = {
    .uart = DEVICE_DT_GET(DT_NODELABEL(uart0)),
    .header = &uart_header,
	.ringbuf = &uart_ringbuf,
    .packet = (uint8_t*)&inputs,
    .packet_max_len = sizeof(inputs),
	.serial_sem = &serial_data,
};

/* A B C D E F DP */
uint8_t seg_to_col[8] = {0, 2, 4, 6, 5, 1, 3, 7};
#define DIGIT_BASE 3 /* Digits start at A3 */

uint8_t char_to_segments(char ch)
{
    /* Translates bitmaps made for a 7-segment connected to a
     * shift register into bitmaps that will fit the led displays
     * wired to the ht16k33. */

    uint8_t map = 0;

    if ((ch >= 'a') && (ch <= 'z')) {
        map = letters[ch - 'a'];
    } else if ((ch >= 'A') && (ch <= 'Z')) {
        map = letters[ch - 'A'];
    } else if ((ch >= '0') && (ch <= '9')) {
        map = numbers[ch - '0'];
    } else if (ch == '.') {
        map = symbols[0];
    } else if (ch == ' ') {
        map = symbols[1];
    } else if (ch == '*') {
        map = symbols[2];
    } else if (ch == '#') {
        map = symbols[3];
    }

    return map;
}

/* leds -> 8 elements */
/* each bit/segment in the bitfield has a led number that needs to be turned on
 * or off. */
void write_seg_bitfield(const struct device *led,
			uint8_t bitfield, uint8_t digit)
{
	__ASSERT_NO_MSG(led);
	__ASSERT_NO_MSG(digit < 8);

	LOG_DBG("mask %x", bitfield);
	uint32_t id;
	for (int i=0; i<8; i++) {
		id = seg_to_col[i] * 16; /* compute segment */
		id += (digit + DIGIT_BASE); /* compute digit */
		LOG_DBG("bit %u id %u", i, id);
		if (bitfield & (1 << i)) {
			led_on(led, id);
		} else {
			led_off(led, id);
		}
	}
}

char seg_buf[8];
void write_segs(const struct device *led, char* seg)
{
	for(int i=0; i<4; i++)
		write_seg_bitfield(led,
				   char_to_segments(seg[i]), i);
}

/* Display helpers */
/* Clears display buffer and flushes it */
void clear_disp(const struct device *led)
{
	write_segs(led, "        ");
}

void push_char(char val, char* seg)
{
	/* Shift chars left */
	for(int i=0; i < 3; i++) {
		seg[i] = seg[i+1];
	}
	seg[3] = val;
}

#define DISP_DELAY_MS 300
void disp_string(const struct device *led, char* str)
{
	do {
		push_char(*str++, seg_buf);
		write_segs(led, seg_buf);
		k_msleep(DISP_DELAY_MS);
	} while(*str);
}

#define GRAPH_ROW_BASE 1

/* level: 0-9, col: 0-2 */
void write_bargraph_level(const struct device *led,
			  uint8_t level, uint8_t col)
{
	__ASSERT_NO_MSG(level < 11);
	__ASSERT_NO_MSG(col < 3);
	__ASSERT_NO_MSG(led);

	uint32_t id;

	for (int i=1; i<11; i++) {
		id = col * 16;
		id += (i-1) + GRAPH_ROW_BASE;
		if (level >= i) {
			led_on(led, id);
		} else {
			led_off(led, id);
		}
	}
}

#define ORANGE_COL_BASE 3
#define ORANGE_ROW_BASE 13

void write_orange_led(const struct device *led,
		      bool state, uint8_t col)
{
	__ASSERT_NO_MSG(col < 3);
	__ASSERT_NO_MSG(led);

	uint32_t id;
	/* This is super confusing:
	 * - the led driver's COLUMN refers to the cathode of the LED
	 * - the parameter `col`(umn) refers to the number of the LED
	 *   (left, middle or right)
	 */

	id = col + ORANGE_ROW_BASE;
	id += ORANGE_COL_BASE * 16;

	/* Weird that the zephyr led API doesn't expose a `set_state` */
	if (state) led_on(led, id);
	else led_off(led, id);
}

void main(void)
{
	if (usb_enable(NULL)) {
		return;
	}

	printk("Hello World!\n");

	const struct device *led = DEVICE_DT_GET(SEG_LED_NODE);

	if (!device_is_ready(led)) {
		LOG_ERR("segments not ready");
		return;
	}

	const struct device *bar = DEVICE_DT_GET(BAR_LED_NODE);

	if (!device_is_ready(bar)) {
		LOG_ERR("bargraph not ready");
		return;
	}

	serial_init(&config);

	const struct device *pwm_dev = DEVICE_DT_GET(DT_ALIAS(pwm_0));
	uint32_t period = PWM_USEC(1000);
	pwm_set(pwm_dev, 0, period, 0, 0);

	LOG_INF("Displaying string");
	disp_string(led, "bonjour rachel");
	clear_disp(led);
	k_msleep(500);

	while (1) {
		k_sem_take(&serial_data, K_FOREVER);

		LOG_INF("Writing bargraph");
		for (int col=0; col < 3; col++) {
			uint32_t level = inputs.slider[col] / 100;
			level = MIN(level, 10);
			write_bargraph_level(bar, level, col);
		}

		LOG_INF("Writing orange leds");
		do {
			int i = 2;
			for (int orangeled = 0; orangeled < 3; orangeled++) {
				bool ledstate = inputs.toggles & (1 << i--);
				write_orange_led(bar, ledstate, orangeled);
			}
		} while (0);

		LOG_INF("Writing keypad");
		if (inputs.keypad != 0) {
			push_char((char)inputs.keypad, seg_buf);
			write_segs(led, seg_buf);
		}

		LOG_INF("Writing analog gauge");
		do {
			uint16_t level = inputs.pot[1] + inputs.pot[2];
			level /= 2;
			level = MIN(level, 1000);
			pwm_set(pwm_dev, 0, PWM_USEC(1000), PWM_USEC(level), 0);
		} while(0);

		LOG_INF("Writing second display");
		do {
			char butchar;
			if (inputs.buttons < 10) {
				butchar = inputs.buttons + '0';
			} else {
				butchar = inputs.buttons - 10 + 'a';
			}

			char line2[5];
			snprintf(&line2[1], 4, "%3d", inputs.pot[0] / 10);
			line2[0] = butchar;

			for(int i=4; i<8; i++) {
				write_seg_bitfield(led,
						   char_to_segments(line2[i-4]), i);
			}
		} while(0);

		/* --------------------------------------------------------------- */

		/* LOG_INF("Reading sensors"); */
		/* for (int i=0; i<300; i++) { */
		/* 	k_sem_take(&serial_data, K_FOREVER); */

		/* 	LOG_INF("Pots: %u\t %u\t %u\t" */
		/* 		"Sliders: %u\t %u\t %u\t" */
		/* 		"keypad: %c\t buttons %u\t toggles %u", */
		/* 		inputs.pot[0], inputs.pot[1], inputs.pot[2], */
		/* 		inputs.slider[0], inputs.slider[1], inputs.slider[2], */
		/* 		(char)inputs.keypad, inputs.buttons, inputs.toggles); */

		/* 	k_msleep(100); */
		/* } */
	}
}
