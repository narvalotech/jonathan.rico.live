#include <zephyr/kernel.h>
#include <zephyr/init.h>

#include <zephyr/usb/usb_device.h>
#include <zephyr/usb/class/usb_hid.h>

#include "usb.h"

#include <zephyr/logging/log.h>
LOG_MODULE_DECLARE(main, 4);

K_SEM_DEFINE(rx_sem, 0, 1);

static bool configured;
static const struct device *hdev;

#define REPORT_ID_1		0x01

/*
 * Simple HID Report Descriptor
 * Report ID is present for completeness, although it can be omitted.
 * Output of "usbhid-dump -d 2fe3:0006 -e descriptor":
 *  05 01 09 00 A1 01 15 00    26 FF 00 85 01 75 08 95
 *  01 09 00 81 02 C0
 */
static const uint8_t hid_report_desc[] = {
	HID_USAGE_PAGE(HID_USAGE_GEN_DESKTOP),
	HID_USAGE(HID_USAGE_GEN_DESKTOP_UNDEFINED),
	HID_COLLECTION(HID_COLLECTION_APPLICATION),
	HID_LOGICAL_MIN8(0x00),
	HID_LOGICAL_MAX16(0xFF, 0x00),
	HID_REPORT_ID(REPORT_ID_1),
	HID_REPORT_SIZE(8),
	HID_REPORT_COUNT(1),
	HID_USAGE(HID_USAGE_GEN_DESKTOP_UNDEFINED),
	HID_INPUT(0x02),
	HID_END_COLLECTION,
};

static void int_out_ready_cb(const struct device *dev)
{
	ARG_UNUSED(dev);
	k_sem_give(&rx_sem);
}

static const struct hid_ops ops = {
	.int_out_ready = int_out_ready_cb,
};

static void status_cb(enum usb_dc_status_code status, const uint8_t *param)
{
	switch (status) {
	case USB_DC_RESET:
		configured = false;
		break;
	case USB_DC_CONFIGURED:
		if (!configured) {
			configured = true;
		}
		break;
	case USB_DC_SOF:
		break;
	default:
		LOG_DBG("status %u unhandled", status);
		break;
	}
}

void usb_init(data_recv cb)
{
	int ret = usb_enable(status_cb);
	if (ret != 0) {
		LOG_ERR("Failed to enable USB");
		return;
	}

	uint8_t data[10] = {0};
	uint32_t bytes_read = 0;

	while (1) {
		k_sem_take(&rx_sem, K_FOREVER);

		do {
			ret = hid_int_ep_read(hdev, &data[0], sizeof(data), &bytes_read);
			if (ret != 0) {
				/*
				* Do nothing and wait until host has reset the device
				* and hid_ep_busy is cleared.
				*/
				LOG_ERR("Failed to read: %d", ret);
			} else {
				cb(data, (uint16_t)bytes_read);
				LOG_DBG("Read %d bytes", bytes_read);
			}
		} while (!ret && bytes_read);
	}
}

static int composite_pre_init(const struct device *dev)
{
	hdev = device_get_binding("HID_0");
	if (hdev == NULL) {
		LOG_ERR("Cannot get USB HID Device");
		return -ENODEV;
	}

	LOG_INF("HID Device: dev %p", hdev);

	usb_hid_register_device(hdev, hid_report_desc, sizeof(hid_report_desc),
				&ops);

	if (usb_hid_set_proto_code(hdev, HID_BOOT_IFACE_CODE_NONE)) {
		LOG_WRN("Failed to set Protocol Code");
	}

	return usb_hid_init(hdev);
}

SYS_INIT(composite_pre_init, APPLICATION, CONFIG_KERNEL_INIT_PRIORITY_DEVICE);
