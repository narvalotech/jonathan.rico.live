#ifndef USB_H_
#define USB_H_

#include <stdint.h>

typedef void (*data_recv)(uint8_t *data, uint16_t len);

void usb_init(data_recv cb);

#endif // USB_H_
