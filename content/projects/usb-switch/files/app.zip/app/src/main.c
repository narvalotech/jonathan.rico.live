#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/devicetree.h>

#include <zephyr/drivers/gpio.h>
#include <zephyr/drivers/led.h>

#include "usb.h"

#include <zephyr/logging/log.h>
LOG_MODULE_REGISTER(main, 4);

#define LEDS_NODE_ID	 DT_COMPAT_GET_ANY_STATUS_OKAY(gpio_leds)

const char *led_label[] = {
	DT_FOREACH_CHILD_SEP_VARGS(LEDS_NODE_ID, DT_PROP_OR, (,), label, NULL)
};

const int num_leds = ARRAY_SIZE(led_label);

enum led_nums {
	LED_DATA = 0x00,
	LED_PWR,
	LED_ALT,
};

#define GPIO_PIN(name) DT_PHA(DT_PATH(outputs, name ), gpios, pin)

void init_gpios(void)
{
	const struct device *port =
		DEVICE_DT_GET(DT_PHANDLE(DT_PATH(outputs, gpio_usb_oe), gpios));

	uint32_t out_flags = GPIO_OUTPUT;

	gpio_pin_configure(port, GPIO_PIN(gpio_usb_pwr), out_flags);
	gpio_pin_set(port, GPIO_PIN(gpio_usb_pwr), 1);

	gpio_pin_configure(port, GPIO_PIN(gpio_alt_pwr), out_flags);
	gpio_pin_set(port, GPIO_PIN(gpio_alt_pwr), 1);

	gpio_pin_configure(port, GPIO_PIN(gpio_ext_usb), out_flags);
	gpio_pin_set(port, GPIO_PIN(gpio_ext_usb), 1);

	gpio_pin_configure(port, GPIO_PIN(gpio_ext_pwr), out_flags);
	gpio_pin_set(port, GPIO_PIN(gpio_ext_pwr), 1);

	gpio_pin_configure(port, GPIO_PIN(gpio_usb_oe), out_flags);
	gpio_pin_set(port, GPIO_PIN(gpio_usb_oe), 0);

	gpio_pin_configure(port, GPIO_PIN(gpio_usb_sel), out_flags);
	gpio_pin_set(port, GPIO_PIN(gpio_usb_sel), 0);
}

enum chans {
	ALL = 0x00,
	DATA,
	USB_PWR,
	ALT_PWR,
	EXT_PWR,
	EXT_USB,
};

void set_chan(uint8_t chan, bool state)
{
	const struct device *port =
		DEVICE_DT_GET(DT_PHANDLE(DT_PATH(outputs, gpio_usb_oe), gpios));

	LOG_DBG("chan %d state %u", chan, state);

	switch(chan) {
		case ALL:
			gpio_pin_set(port, GPIO_PIN(gpio_ext_pwr), state);
			gpio_pin_set(port, GPIO_PIN(gpio_ext_usb), state);
			gpio_pin_set(port, GPIO_PIN(gpio_alt_pwr), state);
			gpio_pin_set(port, GPIO_PIN(gpio_usb_pwr), state);
			gpio_pin_set(port, GPIO_PIN(gpio_usb_oe), !state);
			break;
		case DATA:
			gpio_pin_set(port, GPIO_PIN(gpio_usb_oe), !state);
			break;
		case USB_PWR:
			gpio_pin_set(port, GPIO_PIN(gpio_usb_pwr), state);
			break;
		case ALT_PWR:
			gpio_pin_set(port, GPIO_PIN(gpio_alt_pwr), state);
			break;
		case EXT_PWR:
			gpio_pin_set(port, GPIO_PIN(gpio_ext_pwr), state);
			break;
		case EXT_USB:
			gpio_pin_set(port, GPIO_PIN(gpio_ext_usb), state);
			break;
		default:
			LOG_ERR("unknown chan %d", chan);
	}
}

void process_data(uint8_t *data, uint16_t len)
{
	/* Expect this command format:
	 * [dummy byte] [opcode] [1 or 0]
	 */
	LOG_HEXDUMP_DBG(data, len, "recv host data");

	if (len != 3) return;

	const struct device *leds = DEVICE_DT_GET(LEDS_NODE_ID);

	switch(data[1]) {
		case 0x00:
			set_chan(ALL, data[2]);
			break;
		case 0x01:
			set_chan(DATA, data[2]);
			led_set_channel(leds, LED_DATA, data[2]);
			break;
		case 0x02:
			set_chan(USB_PWR, data[2]);
			set_chan(EXT_USB, data[2]);
			led_set_channel(leds, LED_PWR, data[2]);
			break;
		case 0x03:
			set_chan(ALT_PWR, data[2]);
			set_chan(EXT_PWR, data[2]);
			led_set_channel(leds, LED_ALT, data[2]);
			break;
		default:
			LOG_HEXDUMP_ERR(data, len, "unknown cmd");
			return;
	}
}

void main(void)
{
	const struct device *leds;
	uint8_t led;

	init_gpios();

	leds = DEVICE_DT_GET(LEDS_NODE_ID);
	if (!device_is_ready(leds)) {
		LOG_ERR("Device %s is not ready", leds->name);
		return;
	}

	if (!num_leds) {
		LOG_ERR("No LEDs found for %s", leds->name);
		return;
	}

	/* Turn on all LEDs */
	for (led = 0; led < num_leds; led++) {
		LOG_INF("turn on LED %d", led);
		led_on(leds, led);
	}

	/* this doesn't return */
	usb_init(process_data);
}
